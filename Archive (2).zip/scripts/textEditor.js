var initTextEditor = ()=>{
    var textEditor = new cwindow('text-editor', 800, 600, (ele)=>{
		
    });

    demoWindow.title = 'Text Editor';
    demoWindow.width = 800;
    demoWindow.height = 600;
    demoWindow.x = msize.w / 2 - demoWindow.width / 2;
    demoWindow.y = msize.h / 2 - demoWindow.height / 2;
}
    